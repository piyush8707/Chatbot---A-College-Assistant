#!/usr/bin/env python
import os
import sys,types
sys.modules['cgi'] = types.ModuleType("cgi")

def main():
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'college_chatbot.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError("Couldn't import Django.") from exc
    execute_from_command_line(sys.argv)

if __name__ == '__main__':
    main()

