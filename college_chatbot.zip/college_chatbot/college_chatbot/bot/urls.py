from . import views
from django.urls import path, include


urlpatterns = [
    path('', views.chat_view, name='chat'),
    path('get-response/', views.get_response, name='get_response'),
    path('chatbot-response/', views.chatbot_response, name='chatbot_response'),
    ]
