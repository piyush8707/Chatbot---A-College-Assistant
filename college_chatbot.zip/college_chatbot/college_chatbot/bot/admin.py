from django.contrib import admin
from .models import botFAQ
from .models import ChatLog


@admin.register(botFAQ)
class botFAQAdmin(admin.ModelAdmin):
    list_display = ('question', 'answer')
    search_fields = ('question',)
    
@admin.register(ChatLog)
class ChatLogAdmin(admin.ModelAdmin):
    list_display = ("user_query", "bot_response", "timestamp")
    search_fields = ("user_query", "bot_response")
    list_filter = ("timestamp",)