from django.db import models


class botFAQ(models.Model):
    question = models.CharField(max_length=255, unique=True)  # user query
    answer = models.TextField()  # bot response

    def __str__(self):
        return self.question
class ChatLog(models.Model):
    user_query = models.TextField()
    bot_response = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user_query[:50]}..." - {self.timestamp.strftime('%Y-%m-%d %H:%M:%S')}