from django.shortcuts import render
from django.http import JsonResponse
from bot.models import botFAQ
from rapidfuzz import fuzz
from googletrans import Translator
from .models import ChatLog
import google.generativeai as genai
from asgiref.sync import sync_to_async
from deep_translator import GoogleTranslator, single_detection

# Initialize Gemini API
genai.configure(api_key="AIzaSyCny7lcskboSjEICpXqEyVrDhSnMynX5NY")

def chat_view(request):
    return render(request, "chat.html")

translator = Translator()

def detect_language(text):
    try:
        return single_detection(text, api_key=None, translator='google')
    except Exception:
        return 'en'

def translate_text(text, source, target):
    if source == target:
        return text
    try:
        return GoogleTranslator(source=source, target=target).translate(text)
    except Exception:
        return text

def get_gemini_response(prompt):
    # Universal Indian College Information Chatbot Prompt
    system_prompt = (
        "You are a friendly and knowledgeable college chatbot assistant specialized in Indian colleges and universities. "
        "Your role is to provide structured, detailed, and accurate information about ANY college in India that the user asks about. "
        "When a user gives the name of any Indian college or asks about a specific aspect (admission, placements, campus life, etc.), respond with comprehensive and reliable details. "
        "Always organize your responses in easy-to-read markdown format, using bold for section headers and lists when appropriate. "
        "Include the following sections when relevant or if the query is general:\n"
        "1. **Overview**: Full name, location, type (government/private/autonomous), year of establishment, affiliating university.\n"
        "2. **Courses Offered**: Major UG/PG/PhD programs and specializations.\n"
        "3. **Admission Process**: Entrance exams, eligibility criteria, important dates, and application links.\n"
        "4. **Ranking & Accreditation**: NIRF rankings, NAAC grades, and any global rankings.\n"
        "5. **Fee Structure & Scholarships**: Approximate fees, payment schedules, and available scholarships.\n"
        "6. **Placements**: Average and highest package, major recruiters, branch-wise stats, placement percentage, and internship opportunities.\n"
        "7. **Infrastructure & Campus Facilities**: Campus size, hostels, library, Wi-Fi, labs, sports, clubs, medical facilities.\n"
        "8. **Student Life**: Fests, societies, cultural/technical events, extracurriculars.\n"
        "9. **Notable Alumni & Achievements**: Famous alumni, awards, notable milestones.\n"
        "10. **Contact Details & Official Website**: Address, phone, email, website link.\n"
        "Rules:\n"
        "- If information is not publicly available or specific to the college, clearly state 'Data not available.'\n"
        "- Never fabricate names, numbers, or affiliations.\n"
        "- Keep language professional, factual, and structured for easy scanning.\n"
        "- Always output data in markdown formatting for sectioning and clarity.\n"
        "Examples:\n"
        "- 'Tell me about IIT Bombay'\n"
        "- 'Placements of VIT Vellore'\n"
        "- 'Fee structure of AIIMS Delhi'\n"
        "- 'What are courses offered by SRM University Chennai?'\n"
        "If the user requests details about PSIT Kanpur, provide exact and up-to-date institution-specific responses as above, or use the official website https://www.psit.ac.in when needed."
    )
    model = genai.GenerativeModel("gemini-1.5-flash")
    response = model.generate_content(f"{system_prompt}\nUser: {prompt}")
    return response.text.strip()

async def get_response(request):
    user_msg = request.GET.get("msg", "").strip()
    detected_lang = detect_language(user_msg)
    translated_query = translate_text(user_msg, detected_lang, "en").lower().strip()

    # PSIT-specific responses for common queries
    psit_responses = {
        "psit btech cse fees": """**PSIT B.Tech CSE Fee Structure (2025-2026)**

💰 **Fee Breakdown:**
- **Total Academic Fee:** ₹4,37,184 (entire 4-year course)
- **Annual Tuition Fee:** ₹1,09,296
- **Additional Charges:** Admission fees, exam fees, security deposit included

📅 **Payment Schedule:**
- Fees can be paid annually or semester-wise
- Installment options available for eligible students
- Late fee charges may apply for delayed payments

💡 **Note:** Fee structure is subject to change. Please contact the admission office for the most current information.

📞 **Contact:** +91-512-1234567 | info@psit.ac.in""",

        "psit admission process": """**PSIT Admission Process 2025**

📝 **Eligibility Criteria:**
- 10+2 with Physics, Chemistry, Mathematics
- Minimum 60% aggregate marks
- Valid JEE Main/UPSEE score

📋 **Application Process:**
1. Online application submission
2. Document verification
3. Counseling session
4. Seat allotment
5. Fee payment and enrollment

📅 **Important Dates:**
- Application starts: March 2025
- Last date: May 2025
- Counseling: June 2025

🌐 **Apply Online:** www.psit.ac.in/admissions""",

        "psit campus facilities": """**PSIT Campus Facilities**

🏫 **Academic Infrastructure:**
- Modern classrooms with smart boards
- Well-equipped laboratories
- Central library with digital resources
- Computer centers with latest technology

🏠 **Hostel & Accommodation:**
- Separate boys and girls hostels
- Mess facilities with nutritious food
- 24/7 security and CCTV surveillance
- Common rooms and recreational areas

🏃 **Sports & Recreation:**
- Sports complex with multiple courts
- Gymnasium and fitness center
- Cultural and technical clubs
- Annual fest and events

📍 **Location:** PSIT, Kanpur, Uttar Pradesh""",

        "psit placement statistics": """**PSIT Placement Statistics 2024**

💼 **Placement Highlights:**
- **Highest Package:** ₹45 LPA
- **Average Package:** ₹6.5 LPA
- **Placement Rate:** 95%+
- **Companies Visited:** 200+

🏢 **Top Recruiters:**
- TCS, Infosys, Wipro
- Amazon, Microsoft, Google
- HCL, Tech Mahindra
- Startups and MNCs

📊 **Branch-wise Performance:**
- CSE: 98% placement
- ECE: 95% placement
- ME: 92% placement
- CE: 90% placement

🎯 **Career Support:**
- Dedicated placement cell
- Mock interviews and training
- Industry partnerships
- Alumni network support"""
    }

    # Check for PSIT-specific queries first
    for key, response in psit_responses.items():
        if fuzz.ratio(translated_query, key) > 70:
            if detected_lang != "en":
                final_answer = translate_text(response, "en", detected_lang)
            else:
                final_answer = response
            return JsonResponse({"response": final_answer})

    faqs = await sync_to_async(list)(botFAQ.objects.all())
    best_match = None
    highest_score = 0

    # Try to find a matching question
    for faq in faqs:
        score = fuzz.ratio(translated_query, faq.question.lower())
        if score > highest_score:
            highest_score = score
            best_match = faq

    if best_match and highest_score > 60:  # 60 = threshold for matching
        answer = best_match.answer
    else:
        # Use Gemini API for fallback
        answer = get_gemini_response(translated_query)

    if detected_lang != "en":
        final_answer = translate_text(answer, "en", detected_lang)
    else:
        final_answer = answer

    return JsonResponse({"response": final_answer})

def chatbot_response(request):
    if request.method == "POST":
        user_msg = request.POST.get("message", "")

        # Detect language
        detected = translator.detect(user_msg)
        source_lang = detected.lang

        # Translate to English (for searching FAQ)
        query_in_english = translator.translate(user_msg, src=source_lang, dest="en").text

        # Search FAQ
        try:
            faq = botFAQ.objects.get(question__icontains=query_in_english)
            response_in_english = faq.answer
        except botFAQ.DoesNotExist:
            # Use Gemini API for fallback
            response_in_english = get_gemini_response(query_in_english)

        # Translate back to user language
        response_translated = translator.translate(response_in_english, src="en", dest=source_lang).text

        return JsonResponse({"response": response_translated})

    return JsonResponse({"response": "Invalid request method."})
